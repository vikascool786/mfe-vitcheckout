/****************************************************************************
 ** @license
 ** This file is part of yFiles for HTML 2.6.0.4.
 **
 ** yWorks proprietary/confidential. Use is subject to license terms.
 **
 ** Copyright (c) 2024 by yWorks GmbH, Vor dem Kreuzberg 28,
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ***************************************************************************/
import y from"./impl/layout-cactus.js";export var CactusGroupLayout=y.layout.CactusGroupLayout;export default y;